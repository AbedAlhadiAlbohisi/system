<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();

        // Permission::create(['name' => 'Create-admin', 'guard_name' => 'user']);
        // Permission::create(['name' => 'Read-admins', 'guard_name' => 'user']);
        // Permission::create(['name' => 'Update-admin', 'guard_name' => 'user']);
        // Permission::create(['name' => 'Delete-admin', 'guard_name' => 'user']);

        // Permission::create(['name' => 'Create-User', 'guard_name' => 'user']);
        // Permission::create(['name' => 'Read-Users', 'guard_name' => 'user']);
        // Permission::create(['name' => 'Update-User', 'guard_name' => 'user']);
        // Permission::create(['name' => 'Delete-User', 'guard_name' => 'user']);


        // Permission::create(['name' => 'Create-Role', 'guard_name' => 'user']);
        // Permission::create(['name' => 'Read-Roles', 'guard_name' => 'user']);
        // Permission::create(['name' => 'Update-Role', 'guard_name' => 'user']);
        // Permission::create(['name' => 'Delete-Role', 'guard_name' => 'user']);

        // Permission::create(['name' => 'Create-Permission', 'guard_name' => 'user']);
        // Permission::create(['name' => 'Read-Permissions', 'guard_name' => 'user']);
        // Permission::create(['name' => 'Update-Permission', 'guard_name' => 'user']);
        // Permission::create(['name' => 'Delete-Permission', 'guard_name' => 'user']);

        // Permission::create(['name' => 'Create-Sike', 'guard_name' => 'user']);
        // Permission::create(['name' => 'Read-Sikes', 'guard_name' => 'user']);
        // Permission::create(['name' => 'Update-Sike', 'guard_name' => 'user']);
        // Permission::create(['name' => 'Delete-Sike', 'guard_name' => 'user']);


        // Permission::create(['name' => 'Create-Note', 'guard_name' => 'user']);
        // Permission::create(['name' => 'Read-Notes', 'guard_name' => 'user']);
        // Permission::create(['name' => 'Update-Note', 'guard_nam ' => 'user']);
        // Permission::create(['name' => 'Delete-Note', 'guard_name' => 'user']);

        // Permission::create(['name' => 'Delete-Note', 'guard_name' => 'admin']);


        Permission::create(['name' => 'Create-category', 'guard_name' => 'user']);
        Permission::create(['name' => 'Read-categories', 'guard_name' => 'user']);
        Permission::create(['name' => 'Update-category', 'guard_name' => 'user']);
        Permission::create(['name' => 'Delete-category', 'guard_name' => 'user']);




        Permission::create(['name' => 'Create-subcategory', 'guard_name' => 'user']);
        Permission::create(['name' => 'Read-subcategories', 'guard_name' => 'user']);
        Permission::create(['name' => 'Update-subcategory', 'guard_name' => 'user']);
        Permission::create(['name' => 'Delete-subcategory', 'guard_name' => 'user']);



        Permission::create(['name' => 'Read-categories', 'guard_name' => 'admin']);
        Permission::create(['name' => 'Delete-category', 'guard_name' => 'admin']);

        Permission::create(['name' => 'Read-subcategories', 'guard_name' => 'admin']);
        Permission::create(['name' => 'Delete-subcategory', 'guard_name' => 'admin']);

    }
}
